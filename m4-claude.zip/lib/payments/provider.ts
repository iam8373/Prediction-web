import 'server-only'

/**
 * Payment provider abstraction.
 *
 * Nothing in the app talks to a payment gateway directly. Swap `mockProvider`
 * for a compliant Indian PSP (UPI / netbanking) by implementing this interface
 * and exporting it from `getPaymentProvider()`. No card numbers, UPI
 * credentials or bank passwords are ever accepted or stored by this app.
 */

export type PaymentStatus = 'created' | 'pending' | 'succeeded' | 'failed'

export interface PaymentIntent {
  id: string
  /** Caller supplied key — replaying the same key must never double charge. */
  idempotencyKey: string
  amountPaise: number
  status: PaymentStatus
  createdAt: number
  method: 'upi' | 'netbanking' | 'demo'
  reference: string
}

export interface PaymentProvider {
  readonly name: string
  createDeposit(input: {
    amountPaise: number
    idempotencyKey: string
    method?: PaymentIntent['method']
  }): Promise<PaymentIntent>
  verifyPayment(intentId: string): Promise<PaymentIntent>
  createWithdrawal(input: {
    amountPaise: number
    idempotencyKey: string
    destination: string
  }): Promise<PaymentIntent>
  /** Reverses a prior deposit or cancels a pending withdrawal. Always settles instantly in the demo provider. */
  refundPayment(input: {
    amountPaise: number
    idempotencyKey: string
    originalReference: string
  }): Promise<PaymentIntent>
  getPaymentStatus(intentId: string): Promise<PaymentStatus>
}

function reference(prefix: string) {
  const stamp = Date.now().toString(36).toUpperCase()
  const noise = Math.floor(Math.random() * 1_679_616)
    .toString(36)
    .toUpperCase()
    .padStart(4, '0')
  return `${prefix}${stamp}${noise}`
}

/**
 * Demo provider. It settles instantly and moves no real money — the UI must
 * always label these balances as demo funds.
 */
class MockPaymentProvider implements PaymentProvider {
  readonly name = 'demo'
  private intents = new Map<string, PaymentIntent>()
  private byKey = new Map<string, string>()

  private create(
    amountPaise: number,
    idempotencyKey: string,
    method: PaymentIntent['method'],
    prefix: string,
  ): PaymentIntent {
    const existingId = this.byKey.get(idempotencyKey)
    if (existingId) return this.intents.get(existingId)!
    const intent: PaymentIntent = {
      id: reference('pi_'),
      idempotencyKey,
      amountPaise,
      status: 'succeeded',
      createdAt: Date.now(),
      method,
      reference: reference(prefix),
    }
    this.intents.set(intent.id, intent)
    this.byKey.set(idempotencyKey, intent.id)
    return intent
  }

  async createDeposit({
    amountPaise,
    idempotencyKey,
    method = 'demo',
  }: {
    amountPaise: number
    idempotencyKey: string
    method?: PaymentIntent['method']
  }) {
    await delay()
    return this.create(amountPaise, idempotencyKey, method, 'DEP')
  }

  async createWithdrawal({
    amountPaise,
    idempotencyKey,
  }: {
    amountPaise: number
    idempotencyKey: string
    destination: string
  }) {
    await delay()
    return this.create(amountPaise, idempotencyKey, 'demo', 'WDL')
  }

  async refundPayment({
    amountPaise,
    idempotencyKey,
  }: {
    amountPaise: number
    idempotencyKey: string
    originalReference: string
  }) {
    await delay()
    return this.create(amountPaise, idempotencyKey, 'demo', 'RFD')
  }

  async verifyPayment(intentId: string) {
    await delay(200)
    const intent = this.intents.get(intentId)
    if (!intent) throw new Error('Unknown payment intent')
    return intent
  }

  async getPaymentStatus(intentId: string) {
    const intent = await this.verifyPayment(intentId)
    return intent.status
  }
}

function delay(ms = 650) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

const provider: PaymentProvider = new MockPaymentProvider()

export function getPaymentProvider(): PaymentProvider {
  return provider
}
