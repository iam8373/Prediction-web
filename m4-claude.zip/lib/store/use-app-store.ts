'use client'

import { create } from 'zustand'

import type {
  AdminTransaction,
  Market,
  Notification,
  Position,
  ProfileStats,
  ReferralSummary,
  SessionUser,
  Trade,
  Transaction,
  Wallet,
} from '@/types'
import type { MarketFormInput } from '@/lib/validation/schemas'

export interface ActionResult {
  ok: boolean
  error?: string
  transactionId?: string
}

interface AccountPayload {
  user: SessionUser
  wallet: Wallet
  positions: Position[]
  transactions: Transaction[]
  trades: Trade[]
  watchlist: string[]
  notifications: Notification[]
  unreadNotifications: number
  profileStats: ProfileStats
  referral: ReferralSummary
}

interface AppState {
  hydrated: boolean
  user: SessionUser | null
  wallet: Wallet
  positions: Position[]
  transactions: Transaction[]
  trades: Trade[]
  markets: Market[]
  watchlist: string[]
  notifications: Notification[]
  unreadNotifications: number
  profileStats: ProfileStats
  referral: ReferralSummary
  pendingOtp: string | null
  adminTransactions: AdminTransaction[]
  adminTransactionsLoading: boolean

  hydrate: () => Promise<void>
  requestOtp: (phone: string) => Promise<string>
  signIn: (phone: string, otp: string) => Promise<ActionResult>
  signOut: () => Promise<void>
  deposit: (amountPaise: number, method?: 'upi' | 'netbanking' | 'demo') => Promise<ActionResult>
  withdraw: (amountPaise: number, destination: string) => Promise<ActionResult>
  buy: (marketId: string, outcomeId: string, amountPaise: number) => Promise<ActionResult>
  sell: (marketId: string, outcomeId: string, milliShares: number) => Promise<ActionResult>
  toggleWatch: (marketId: string) => Promise<ActionResult>
  markNotificationRead: (id: string) => Promise<ActionResult>
  markAllNotificationsRead: () => Promise<ActionResult>
  claimReferral: (code: string) => Promise<ActionResult>
  createMarket: (input: MarketFormInput) => Promise<ActionResult>
  resolveMarket: (marketId: string, outcomeId: string) => Promise<ActionResult>
  setMarketStatus: (marketId: string, status: 'open' | 'paused' | 'closed') => Promise<ActionResult>
  adminFetchTransactions: (query?: string) => Promise<void>
  adminRefundTransaction: (transactionId: string, reason?: string) => Promise<ActionResult>
}

const emptyWallet: Wallet = { availablePaise: 0, lockedPaise: 0, bonusPaise: 0 }

function requestId() {
  return `${Date.now().toString(36)}-${crypto.randomUUID()}`
}

async function readJson<T>(response: Response): Promise<T> {
  const body = (await response.json()) as T
  if (!response.ok) throw new Error((body as { error?: string }).error ?? 'Request failed')
  return body
}

async function fetchMarkets() {
  const response = await fetch('/api/markets', { cache: 'no-store' })
  return readJson<{ markets: Market[] }>(response)
}

async function fetchAccount() {
  const response = await fetch('/api/me', { cache: 'no-store' })
  if (response.status === 401) return null
  return readJson<AccountPayload>(response)
}

const emptyProfileStats: ProfileStats = {
  tradeCount: 0,
  marketsParticipated: 0,
  openPositions: 0,
  resolvedPositions: 0,
  volumePaise: 0,
}

const emptyReferral: ReferralSummary = {
  code: '',
  invitedCount: 0,
  claimedCount: 0,
  rewardPaise: 0,
  referrals: [],
}

const resetAccount = {
  user: null as SessionUser | null,
  wallet: emptyWallet,
  positions: [] as Position[],
  transactions: [] as Transaction[],
  trades: [] as Trade[],
  watchlist: [] as string[],
  notifications: [] as Notification[],
  unreadNotifications: 0,
  profileStats: emptyProfileStats,
  referral: emptyReferral,
}

export const useAppStore = create<AppState>((set, get) => ({
  hydrated: false,
  ...resetAccount,
  markets: [],
  pendingOtp: null,
  adminTransactions: [],
  adminTransactionsLoading: false,

  async hydrate() {
    if (get().hydrated) return
    try {
      const [account, marketPayload] = await Promise.all([fetchAccount(), fetchMarkets()])
      set({
        hydrated: true,
        markets: marketPayload.markets,
        ...(account ?? resetAccount),
      })
    } catch (error) {
      console.error('[v0] account hydration failed', error)
      set({ hydrated: true })
    }
  },

  async requestOtp(phone) {
    const response = await fetch('/api/auth/otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'request', phone }),
    })
    const body = await readJson<{ demoCode?: string }>(response)
    const code = body.demoCode ?? '424242'
    set({ pendingOtp: code })
    return code
  },

  async signIn(phone, otp) {
    try {
      const response = await fetch('/api/auth/otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify', phone, otp }),
      })
      const body = await readJson<{ user: SessionUser }>(response)
      const [account, marketPayload] = await Promise.all([fetchAccount(), fetchMarkets()])
      if (!account) return { ok: false, error: 'We could not load your account. Try again.' }
      set({ ...account, markets: marketPayload.markets, hydrated: true, pendingOtp: null })
      return { ok: true }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Sign in failed' }
    }
  },

  async signOut() {
    try {
      await fetch('/api/auth/sign-out', { method: 'POST' })
    } finally {
      set({ ...resetAccount, hydrated: true, pendingOtp: null })
    }
  },

  async deposit(amountPaise, method = 'demo') {
    try {
      const response = await fetch('/api/wallet/deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId() },
        body: JSON.stringify({ amountPaise, method }),
      })
      const body = await readJson<{ transactionId: string }>(response)
      const account = await fetchAccount()
      if (account) set(account)
      return { ok: true, transactionId: body.transactionId }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Deposit failed' }
    }
  },

  async withdraw(amountPaise, destination) {
    try {
      const response = await fetch('/api/wallet/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId() },
        body: JSON.stringify({ amountPaise, destination }),
      })
      const body = await readJson<{ transactionId: string }>(response)
      const account = await fetchAccount()
      if (account) set(account)
      return { ok: true, transactionId: body.transactionId }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Withdrawal failed' }
    }
  },

  async buy(marketId, outcomeId, amountPaise) {
    try {
      const response = await fetch('/api/trading/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId() },
        body: JSON.stringify({ marketId, outcomeId, side: 'buy', amountPaise }),
      })
      const body = await readJson<{ transactionId: string }>(response)
      const [account, marketPayload] = await Promise.all([fetchAccount(), fetchMarkets()])
      if (account) set({ ...account, markets: marketPayload.markets })
      return { ok: true, transactionId: body.transactionId }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Trade failed' }
    }
  },

  async sell(marketId, outcomeId, milliShares) {
    try {
      const response = await fetch('/api/trading/sell', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId() },
        body: JSON.stringify({ marketId, outcomeId, milliShares }),
      })
      const body = await readJson<{ transactionId: string }>(response)
      const [account, marketPayload] = await Promise.all([fetchAccount(), fetchMarkets()])
      if (account) set({ ...account, markets: marketPayload.markets })
      return { ok: true, transactionId: body.transactionId }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Sell failed' }
    }
  },

  async toggleWatch(marketId) {
    const wasWatching = get().watchlist.includes(marketId)
    const nextWatchlist = wasWatching
      ? get().watchlist.filter((id) => id !== marketId)
      : [marketId, ...get().watchlist]
    set({ watchlist: nextWatchlist })

    try {
      const response = await fetch('/api/watchlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId() },
        body: JSON.stringify({ marketId, watched: !wasWatching }),
      })
      const body = await readJson<{ watched: boolean; watchlist: string[] }>(response)
      set({ watchlist: body.watchlist })
      return { ok: true }
    } catch (error) {
      set({ watchlist: wasWatching ? [...nextWatchlist, marketId] : nextWatchlist.filter((id) => id !== marketId) })
      return { ok: false, error: error instanceof Error ? error.message : 'Could not update watchlist' }
    }
  },

  async markNotificationRead(id) {
    try {
      const response = await fetch('/api/notifications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      })
      const body = await readJson<{ notifications: Notification[]; unread: number }>(response)
      set({ notifications: body.notifications, unreadNotifications: body.unread })
      return { ok: true }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Could not update notification' }
    }
  },

  async markAllNotificationsRead() {
    try {
      const response = await fetch('/api/notifications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ all: true }),
      })
      const body = await readJson<{ notifications: Notification[]; unread: number }>(response)
      set({ notifications: body.notifications, unreadNotifications: body.unread })
      return { ok: true }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Could not update notifications' }
    }
  },

  async claimReferral(code) {
    try {
      const response = await fetch('/api/referrals/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code }),
      })
      await readJson<{ rewardPaise: number }>(response)
      const account = await fetchAccount()
      if (account) set(account)
      return { ok: true }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Could not claim invite' }
    }
  },

  async createMarket(input) {
    try {
      const response = await fetch('/api/admin/markets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      })
      const body = await readJson<{ ok: boolean; marketId?: string }>(response)
      const marketPayload = await fetchMarkets()
      set({ markets: marketPayload.markets })
      return { ok: body.ok, error: body.ok ? undefined : 'The market could not be created' }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Could not create market' }
    }
  },

  async resolveMarket(marketId, outcomeId) {
    try {
      const response = await fetch('/api/admin/markets/resolve', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ marketId, outcomeId }) })
      const body = await readJson<{ ok: boolean; error?: string }>(response)
      if (body.ok) {
        const marketPayload = await fetchMarkets()
        set({ markets: marketPayload.markets })
      }
      return body
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Could not resolve market' }
    }
  },

  async setMarketStatus(marketId, status) {
    try {
      const response = await fetch('/api/admin/markets/status', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ marketId, status }) })
      const body = await readJson<{ ok: boolean; error?: string }>(response)
      if (body.ok) {
        const marketPayload = await fetchMarkets()
        set({ markets: marketPayload.markets })
      }
      return body
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Could not update market' }
    }
  },

  async adminFetchTransactions(query = '') {
    set({ adminTransactionsLoading: true })
    try {
      const response = await fetch(`/api/admin/transactions?query=${encodeURIComponent(query)}`, { cache: 'no-store' })
      const body = await readJson<{ transactions: AdminTransaction[] }>(response)
      set({ adminTransactions: body.transactions, adminTransactionsLoading: false })
    } catch (error) {
      console.error('[v0] admin transaction fetch failed', error)
      set({ adminTransactionsLoading: false })
    }
  },

  async adminRefundTransaction(transactionId, reason) {
    try {
      const response = await fetch('/api/admin/wallet/refund', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transactionId, reason }),
      })
      const body = await readJson<{ transactionId: string }>(response)
      set({ adminTransactions: get().adminTransactions.filter((t) => t.id !== transactionId) })
      return { ok: true, transactionId: body.transactionId }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Could not process refund' }
    }
  },

}))
