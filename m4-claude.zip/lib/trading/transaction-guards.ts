import 'server-only'

import { randomUUID } from 'node:crypto'
import { sql, type SQL } from 'drizzle-orm'

const MAX_REQUEST_KEY_LENGTH = 128

type TransactionExecutor = {
  execute: (query: SQL) => unknown
}

export function getRequestKey(request: Request) {
  const value = request.headers.get('Idempotency-Key')?.trim()
  if (value && value.length > MAX_REQUEST_KEY_LENGTH) {
    throw new Error('INVALID_IDEMPOTENCY_KEY')
  }
  return value || randomUUID()
}

/** Serialize retries and same-resource financial operations inside PostgreSQL. */
export async function lockResource(
  tx: TransactionExecutor,
  scope: string,
  ...parts: string[]
) {
  const key = [scope, ...parts].join(':')
  await tx.execute(sql`select pg_advisory_xact_lock(hashtextextended(${key}, 0))`)
}

export function isUniqueViolation(error: unknown) {
  return typeof error === 'object' && error !== null && 'code' in error && error.code === '23505'
}
