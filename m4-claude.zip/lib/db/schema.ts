import { bigint, boolean, index, integer, jsonb, pgTable, text, timestamp, uniqueIndex } from 'drizzle-orm/pg-core'

export const users = pgTable('user', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  emailVerified: boolean('emailVerified').notNull().default(false),
  image: text('image'),
  phoneNumber: text('phoneNumber'),
  phoneNumberVerified: boolean('phoneNumberVerified').notNull().default(false),
  avatarColor: text('avatarColor').notNull().default('oklch(0.65 0.2 30)'),
  isAdmin: boolean('isAdmin').notNull().default(false),
  createdAt: timestamp('createdAt', { mode: 'date' }).notNull().defaultNow(),
  updatedAt: timestamp('updatedAt', { mode: 'date' }).notNull().defaultNow(),
}, (table) => ({
  emailIdx: uniqueIndex('user_email_idx').on(table.email),
  phoneIdx: uniqueIndex('user_phone_idx').on(table.phoneNumber),
}))

export const sessions = pgTable('session', {
  token: text('token').primaryKey(),
  userId: text('user_id').notNull(),
  expiresAt: timestamp('expires_at', { mode: 'date' }).notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).notNull().defaultNow(),
}, (table) => ({
  userIdx: index('session_user_idx').on(table.userId),
  expiryIdx: index('session_expiry_idx').on(table.expiresAt),
}))

export const otpChallenges = pgTable('otp_challenge', {
  id: text('id').primaryKey(),
  phone: text('phone').notNull(),
  codeHash: text('code_hash').notNull(),
  expiresAt: timestamp('expires_at', { mode: 'date' }).notNull(),
  attempts: integer('attempts').notNull().default(0),
  consumedAt: timestamp('consumed_at', { mode: 'date' }),
  createdAt: timestamp('created_at', { mode: 'date' }).notNull().defaultNow(),
}, (table) => ({
  phoneIdx: index('otp_phone_idx').on(table.phone),
  expiryIdx: index('otp_expiry_idx').on(table.expiresAt),
}))

export const categories = pgTable('category', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  slug: text('slug').notNull(),
  icon: text('icon').notNull(),
  accent: text('accent').notNull(),
}, (table) => ({
  slugIdx: uniqueIndex('category_slug_idx').on(table.slug),
}))

export const markets = pgTable('market', {
  id: text('id').primaryKey(),
  slug: text('slug').notNull(),
  question: text('question').notNull(),
  headline: text('headline').notNull(),
  description: text('description').notNull(),
  resolutionCriteria: text('resolution_criteria').notNull(),
  source: text('source').notNull(),
  categoryId: text('category_id').notNull(),
  kind: text('kind').notNull(),
  status: text('status').notNull(),
  league: text('league'),
  emblem: text('emblem').notNull(),
  live: boolean('live').notNull().default(false),
  featured: boolean('featured').notNull().default(false),
  bonus: boolean('bonus').notNull().default(false),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  opensAt: bigint('opens_at', { mode: 'number' }).notNull(),
  closesAt: bigint('closes_at', { mode: 'number' }).notNull(),
  resolvesAt: bigint('resolves_at', { mode: 'number' }).notNull(),
  resolvedOutcomeId: text('resolved_outcome_id'),
  volumePaise: bigint('volume_paise', { mode: 'number' }).notNull().default(0),
  liquidityPaise: bigint('liquidity_paise', { mode: 'number' }).notNull().default(0),
  traders: integer('traders').notNull().default(0),
}, (table) => ({
  slugIdx: uniqueIndex('market_slug_idx').on(table.slug),
  categoryIdx: index('market_category_idx').on(table.categoryId),
  statusIdx: index('market_status_idx').on(table.status),
  closesIdx: index('market_closes_idx').on(table.closesAt),
}))

export const marketOutcomes = pgTable('market_outcome', {
  id: text('id').primaryKey(),
  marketId: text('market_id').notNull(),
  name: text('name').notNull(),
  side: text('side').notNull(),
  pricePaise: integer('price_paise').notNull(),
  previousPricePaise: integer('previous_price_paise').notNull(),
}, (table) => ({
  marketIdx: index('market_outcome_market_idx').on(table.marketId),
}))

export const marketPriceHistory = pgTable('market_price_history', {
  id: text('id').primaryKey(),
  marketId: text('market_id').notNull(),
  t: bigint('t', { mode: 'number' }).notNull(),
  yesPricePaise: integer('yes_price_paise').notNull(),
}, (table) => ({
  marketTimeIdx: index('market_price_history_market_time_idx').on(table.marketId, table.t),
}))

export const wallets = pgTable('wallet', {
  userId: text('user_id').primaryKey(),
  availablePaise: bigint('available_paise', { mode: 'number' }).notNull().default(0),
  lockedPaise: bigint('locked_paise', { mode: 'number' }).notNull().default(0),
  bonusPaise: bigint('bonus_paise', { mode: 'number' }).notNull().default(0),
  updatedAt: timestamp('updated_at', { mode: 'date' }).notNull().defaultNow(),
})

export const ledgerEntries = pgTable('ledger_entry', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  reference: text('reference').notNull(),
  type: text('type').notNull(),
  amountPaise: bigint('amount_paise', { mode: 'number' }).notNull(),
  status: text('status').notNull(),
  description: text('description').notNull(),
  marketId: text('market_id'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
}, (table) => ({
  referenceIdx: uniqueIndex('ledger_reference_idx').on(table.reference),
  userCreatedIdx: index('ledger_user_created_idx').on(table.userId, table.createdAt),
}))

export const transactions = pgTable('transaction', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  reference: text('reference').notNull(),
  type: text('type').notNull(),
  amountPaise: bigint('amount_paise', { mode: 'number' }).notNull(),
  status: text('status').notNull(),
  description: text('description').notNull(),
  marketId: text('market_id'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
}, (table) => ({
  referenceIdx: uniqueIndex('transaction_reference_idx').on(table.reference),
  userCreatedIdx: index('transaction_user_created_idx').on(table.userId, table.createdAt),
}))

export const positions = pgTable('position', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  marketId: text('market_id').notNull(),
  outcomeId: text('outcome_id').notNull(),
  milliShares: bigint('milli_shares', { mode: 'number' }).notNull(),
  averagePricePaise: integer('average_price_paise').notNull(),
  realisedPnlPaise: bigint('realised_pnl_paise', { mode: 'number' }).notNull().default(0),
  status: text('status').notNull(),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
}, (table) => ({
  userOutcomeIdx: index('position_user_outcome_idx').on(table.userId, table.outcomeId),
  userStatusIdx: index('position_user_status_idx').on(table.userId, table.status),
}))

export const trades = pgTable('trade', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  marketId: text('market_id').notNull(),
  outcomeId: text('outcome_id').notNull(),
  side: text('side').notNull(),
  milliShares: bigint('milli_shares', { mode: 'number' }).notNull(),
  pricePaise: integer('price_paise').notNull(),
  amountPaise: bigint('amount_paise', { mode: 'number' }).notNull(),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
}, (table) => ({
  marketCreatedIdx: index('trade_market_created_idx').on(table.marketId, table.createdAt),
  userCreatedIdx: index('trade_user_created_idx').on(table.userId, table.createdAt),
}))

export const idempotencyKeys = pgTable('idempotency_key', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  requestKey: text('request_key').notNull(),
  response: jsonb('response').$type<Record<string, unknown>>().notNull(),
  createdAt: timestamp('created_at', { mode: 'date' }).notNull().defaultNow(),
}, (table) => ({
  requestIdx: uniqueIndex('idempotency_user_request_idx').on(table.userId, table.requestKey),
}))

export const notifications = pgTable('notification', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  eventKey: text('event_key').notNull(),
  kind: text('kind').notNull(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  href: text('href'),
  readAt: bigint('read_at', { mode: 'number' }),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
}, (table) => ({
  userEventIdx: uniqueIndex('notification_user_event_idx').on(table.userId, table.eventKey),
  unreadIdx: index('notification_user_unread_idx').on(table.userId, table.readAt, table.createdAt),
}))

export const referrals = pgTable('referral', {
  id: text('id').primaryKey(),
  referrerUserId: text('referrer_user_id').notNull(),
  referredUserId: text('referred_user_id'),
  code: text('code').notNull(),
  status: text('status').notNull().default('pending'),
  rewardPaise: bigint('reward_paise', { mode: 'number' }).notNull().default(0),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  claimedAt: bigint('claimed_at', { mode: 'number' }),
}, (table) => ({
  codeIdx: uniqueIndex('referral_code_idx').on(table.code),
  referrerIdx: index('referral_referrer_idx').on(table.referrerUserId, table.createdAt),
}))

export const watchlists = pgTable('watchlist', {
  userId: text('user_id').notNull(),
  marketId: text('market_id').notNull(),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
}, (table) => ({
  userCreatedIdx: index('watchlist_user_created_idx').on(table.userId, table.createdAt),
}))

export const user = users
export const session = sessions
export const category = categories
export const market = markets
export const marketOutcome = marketOutcomes
export const wallet = wallets
export const ledgerEntry = ledgerEntries
export const transaction = transactions
export const position = positions
export const trade = trades
export const idempotencyKey = idempotencyKeys
export const notification = notifications
export const referral = referrals
export const watchlist = watchlists

export type User = typeof users.$inferSelect
export type WalletRow = typeof wallets.$inferSelect
export type MarketRow = typeof markets.$inferSelect
export type MarketOutcomeRow = typeof marketOutcomes.$inferSelect
export type PositionRow = typeof positions.$inferSelect
export type TransactionRow = typeof transactions.$inferSelect
export type TradeRow = typeof trades.$inferSelect
export type NotificationRow = typeof notifications.$inferSelect
export type ReferralRow = typeof referrals.$inferSelect
export type WatchlistRow = typeof watchlists.$inferSelect
