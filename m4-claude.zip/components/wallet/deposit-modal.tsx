'use client'

import { useState } from 'react'

import { Button } from '@/components/ui/button'
import { Modal } from '@/components/ui/modal'
import { inputClass } from '@/components/ui/primitives'
import { useToast } from '@/components/ui/toast'
import { formatINR, rupeesToPaise } from '@/lib/money'
import { useAppStore } from '@/lib/store/use-app-store'
import { cn } from '@/lib/utils'

const QUICK_AMOUNTS = [100, 500, 1000, 5000]
const METHODS = ['upi', 'netbanking', 'demo'] as const

export function DepositModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const deposit = useAppStore((s) => s.deposit)
  const { toast } = useToast()
  const [amount, setAmount] = useState(500)
  const [method, setMethod] = useState<(typeof METHODS)[number]>('upi')
  const [submitting, setSubmitting] = useState(false)

  async function submit() {
    setSubmitting(true)
    const result = await deposit(rupeesToPaise(amount), method)
    setSubmitting(false)
    if (result.ok) {
      toast({
        title: 'Funds added',
        description: `${formatINR(rupeesToPaise(amount))} credited to your wallet`,
        tone: 'success',
      })
      onClose()
    } else {
      toast({ title: 'Deposit failed', description: result.error, tone: 'error' })
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add funds"
      description="Demo deposits settle instantly. No real money is used."
    >
      <div className="space-y-4">
        <div>
          <label htmlFor="deposit-amount" className="mb-1.5 block text-xs font-medium text-muted-foreground">
            Amount
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-semibold text-muted-foreground">
              ₹
            </span>
            <input
              id="deposit-amount"
              type="number"
              min={100}
              value={amount}
              onChange={(e) => setAmount(Math.max(0, Number(e.target.value)))}
              className={cn(inputClass, 'pl-7 text-base font-semibold')}
              data-autofocus
            />
          </div>
          <div className="mt-2 grid grid-cols-4 gap-1.5">
            {QUICK_AMOUNTS.map((amt) => (
              <button
                key={amt}
                type="button"
                onClick={() => setAmount(amt)}
                className={cn(
                  'rounded-lg border py-1.5 text-xs font-medium transition-colors',
                  amount === amt
                    ? 'border-primary bg-accent text-accent-foreground'
                    : 'border-border text-muted-foreground hover:bg-muted',
                )}
              >
                ₹{amt}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-1.5 text-xs font-medium text-muted-foreground">Payment method</p>
          <div className="grid grid-cols-3 gap-1.5">
            {METHODS.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMethod(m)}
                className={cn(
                  'rounded-lg border py-2 text-xs font-semibold uppercase transition-colors',
                  method === m
                    ? 'border-primary bg-accent text-accent-foreground'
                    : 'border-border text-muted-foreground hover:bg-muted',
                )}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <Button
          className="h-11 w-full rounded-xl text-[15px]"
          disabled={submitting || amount < 100}
          onClick={submit}
        >
          {submitting ? 'Processing…' : `Add ${formatINR(rupeesToPaise(amount || 0))}`}
        </Button>
      </div>
    </Modal>
  )
}
