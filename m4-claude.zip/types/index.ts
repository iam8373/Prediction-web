/**
 * Domain types for the Predik web app.
 *
 * Money is ALWAYS an integer number of paise (1 INR = 100 paise).
 * Share quantities are ALWAYS integer milli-shares (1 share = 1000 milli-shares).
 * No float arithmetic is used anywhere in the financial path.
 */

export type MarketStatus = 'open' | 'paused' | 'closed' | 'resolved'
export type MarketKind = 'binary' | 'match'
export type OutcomeSide = 'yes' | 'no'

export interface Category {
  id: string
  name: string
  slug: string
  icon: string
  accent: string
}

export interface MarketOutcome {
  id: string
  marketId: string
  /** "Yes" / "No" or a team short name such as "NDT". */
  name: string
  side: OutcomeSide
  /** Price per share in paise, out of a ₹10 (1000 paise) settlement. */
  pricePaise: number
  /** Price 24h ago, used for movement indicators. */
  previousPricePaise: number
}

export interface PricePoint {
  /** Unix ms timestamp. */
  t: number
  /** Yes price in paise (out of 1000). */
  yes: number
}

export interface MarketStats {
  tradeCount: number
  volumePaise: number
  participants: number
}

export interface Market {
  id: string
  slug: string
  question: string
  /** Short headline used on compact cards, e.g. "NDT vs WDL". */
  headline: string
  description: string
  resolutionCriteria: string
  source: string
  categoryId: string
  kind: MarketKind
  status: MarketStatus
  league?: string
  emblem: string
  live: boolean
  featured: boolean
  bonus: boolean
  createdAt: number
  opensAt: number
  closesAt: number
  resolvesAt: number
  /** Outcome id of the winning outcome once resolved. */
  resolvedOutcomeId?: string
  volumePaise: number
  liquidityPaise: number
  traders: number
  outcomes: MarketOutcome[]
  priceHistory: PricePoint[]
}

export type TransactionType =
  | 'deposit'
  | 'withdrawal'
  | 'buy'
  | 'sell'
  | 'payout'
  | 'fee'
  | 'refund'
  | 'bonus'

export type TransactionStatus = 'pending' | 'completed' | 'failed'

export interface Transaction {
  id: string
  reference: string
  type: TransactionType
  /** Signed amount in paise. Positive credits the wallet, negative debits it. */
  amountPaise: number
  status: TransactionStatus
  createdAt: number
  description: string
  marketId?: string
}

export interface Position {
  id: string
  marketId: string
  outcomeId: string
  /** Integer milli-shares (1000 = 1 share). */
  milliShares: number
  /** Volume weighted average entry price in paise. */
  averagePricePaise: number
  /** Cash realised from sells + settlements, in paise. */
  realisedPnlPaise: number
  status: 'open' | 'closed' | 'settled'
  createdAt: number
  updatedAt: number
}

export interface Trade {
  id: string
  marketId: string
  outcomeId: string
  side: 'buy' | 'sell'
  milliShares: number
  pricePaise: number
  amountPaise: number
  createdAt: number
  trader?: string
}

export interface Wallet {
  availablePaise: number
  lockedPaise: number
  bonusPaise: number
}

export type NotificationKind = 'trade' | 'settlement' | 'market' | 'account'

export interface Notification {
  id: string
  eventKey: string
  kind: NotificationKind
  title: string
  description: string
  href?: string
  readAt?: number
  createdAt: number
}

export interface ReferralSummary {
  code: string
  invitedCount: number
  claimedCount: number
  rewardPaise: number
  referrals: Array<{
    id: string
    status: string
    rewardPaise: number
    createdAt: number
    claimedAt?: number
  }>
}

export interface ProfileStats {
  tradeCount: number
  marketsParticipated: number
  openPositions: number
  resolvedPositions: number
  volumePaise: number
}

export interface SessionUser {
  id: string
  name: string
  phone: string
  avatarColor: string
  isAdmin: boolean
  joinedAt: number
}

export interface MarketFilters {
  category?: string
  query?: string
  sort?: SortKey
  status?: 'live' | 'resolved' | 'all'
  page?: number
  perPage?: number
}

export type SortKey =
  | 'trending'
  | 'volume'
  | 'newest'
  | 'closing'
  | 'probability-high'
  | 'probability-low'

export interface AdminTransaction {
  id: string
  reference: string
  type: TransactionType
  amountPaise: number
  status: TransactionStatus
  createdAt: number
  description: string
  userId: string
  userName: string
  userPhone: string
  refundable: boolean
}

export interface Paginated<T> {
  items: T[]
  total: number
  page: number
  perPage: number
  hasMore: boolean
}
