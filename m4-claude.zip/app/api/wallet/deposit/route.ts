import { and, eq, sql } from 'drizzle-orm'
import { NextResponse } from 'next/server'
import { randomUUID } from 'node:crypto'
import { ZodError } from 'zod'

import { getCurrentUser } from '@/lib/auth/session'
import { db } from '@/lib/db'
import { idempotencyKeys, ledgerEntries, notifications, transactions, wallets } from '@/lib/db/schema'
import { getPaymentProvider } from '@/lib/payments/provider'
import { getRequestKey, lockResource } from '@/lib/trading/transaction-guards'
import { depositSchema } from '@/lib/validation/schemas'

export async function POST(request: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ ok: false, error: 'Sign in to add funds' }, { status: 401 })

  try {
    const input = depositSchema.parse(await request.json())
    const requestKey = getRequestKey(request)
    const response = await db.transaction(async (tx) => {
      await lockResource(tx, 'idempotency', user.id, requestKey)
      const [previous] = await tx
        .select({ response: idempotencyKeys.response })
        .from(idempotencyKeys)
        .where(and(eq(idempotencyKeys.userId, user.id), eq(idempotencyKeys.requestKey, requestKey)))
        .limit(1)
      if (previous) return previous.response

      const [walletBefore] = await tx
        .select()
        .from(wallets)
        .where(eq(wallets.userId, user.id))
        .for('update')
        .limit(1)
      if (!walletBefore) throw new Error('ACCOUNT_NOT_READY')

      const provider = getPaymentProvider()
      const intent = await provider.createDeposit({ amountPaise: input.amountPaise, idempotencyKey: `${user.id}:${requestKey}`, method: input.method })
      const verified = await provider.verifyPayment(intent.id)
      if (verified.status !== 'succeeded') throw new Error('PAYMENT_FAILED')
      if (verified.amountPaise !== input.amountPaise) throw new Error('PAYMENT_MISMATCH')

      const now = Date.now()
      const transactionId = randomUUID()
      const reference = verified.reference
      const [wallet] = await tx
        .update(wallets)
        .set({ availablePaise: sql`${wallets.availablePaise} + ${input.amountPaise}`, updatedAt: new Date() })
        .where(eq(wallets.userId, user.id))
        .returning({ availablePaise: wallets.availablePaise, lockedPaise: wallets.lockedPaise, bonusPaise: wallets.bonusPaise })
      if (!wallet) throw new Error('ACCOUNT_NOT_READY')
      const description = `Deposit via ${input.method.toUpperCase()}`
      await tx.insert(transactions).values({ id: transactionId, userId: user.id, reference, type: 'deposit', amountPaise: input.amountPaise, status: 'completed', description, createdAt: now })
      await tx.insert(ledgerEntries).values({ id: `ledger_${transactionId}`, userId: user.id, reference, type: 'deposit', amountPaise: input.amountPaise, status: 'completed', description, createdAt: now })
      await tx.insert(notifications).values({
        id: `notification_${transactionId}`,
        userId: user.id,
        eventKey: `deposit:${transactionId}`,
        kind: 'account',
        title: 'Deposit completed',
        description,
        href: '/wallet',
        createdAt: now,
      }).onConflictDoNothing()
      const result = { ok: true, transactionId, wallet }
      await tx.insert(idempotencyKeys).values({ id: randomUUID(), userId: user.id, requestKey, response: result })
      return result
    })
    return NextResponse.json(response)
  } catch (error) {
    const message = error instanceof Error ? error.message : ''
    if (error instanceof ZodError) return NextResponse.json({ ok: false, error: error.issues[0]?.message ?? 'Invalid deposit' }, { status: 400 })
    const errors: Record<string, { error: string; status: number }> = {
      INVALID_IDEMPOTENCY_KEY: { error: 'The idempotency key is invalid', status: 400 },
      ACCOUNT_NOT_READY: { error: 'Your wallet is not ready yet. Try again.', status: 409 },
      PAYMENT_FAILED: { error: 'The payment could not be confirmed', status: 400 },
      PAYMENT_MISMATCH: { error: 'The payment amount could not be verified', status: 409 },
    }
    if (errors[message]) return NextResponse.json({ ok: false, error: errors[message].error }, { status: errors[message].status })
    console.error('[v0] deposit failed', error)
    return NextResponse.json({ ok: false, error: 'We could not add funds. Try again.' }, { status: 500 })
  }
}
