import { NextResponse } from 'next/server'

import { getCurrentUser } from '@/lib/auth/session'
import { getAccountSnapshot } from '@/lib/data/server-api'

export async function GET() {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ user: null }, { status: 401 })

  const account = await getAccountSnapshot(user.id)
  return NextResponse.json({ user, ...account })
}
