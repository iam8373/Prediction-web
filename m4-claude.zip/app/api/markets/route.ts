import { NextResponse } from 'next/server'

import { getAllMarkets } from '@/lib/data/server-api'

export async function GET() {
  const markets = await getAllMarkets()
  return NextResponse.json({ markets })
}
