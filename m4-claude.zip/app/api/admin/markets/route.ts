import { NextResponse } from 'next/server'
import { randomUUID } from 'node:crypto'
import { ZodError } from 'zod'

import { getCurrentUser } from '@/lib/auth/session'
import { db } from '@/lib/db'
import { marketOutcomes, marketPriceHistory, markets } from '@/lib/db/schema'
import { marketFormSchema } from '@/lib/validation/schemas'

function slugify(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 72)
}

export async function POST(request: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ ok: false, error: 'Sign in with an admin account' }, { status: 401 })
  if (!user.isAdmin) return NextResponse.json({ ok: false, error: 'Admin access required' }, { status: 403 })

  try {
    const input = marketFormSchema.parse(await request.json())
    const now = Date.now()
    const id = `market_${randomUUID()}`
    const yesPricePaise = Math.round((input.initialYesProbability / 100) * 1000)
    const baseSlug = slugify(input.question) || id
    const slug = `${baseSlug}-${id.slice(-8)}`

    await db.transaction(async (tx) => {
      await tx.insert(markets).values({
        id,
        slug,
        question: input.question,
        headline: `${input.yesLabel} vs ${input.noLabel}`,
        description: input.description,
        resolutionCriteria: input.resolutionCriteria,
        source: input.source,
        categoryId: input.categoryId,
        kind: 'binary',
        status: input.status,
        emblem: input.yesLabel.slice(0, 3).toUpperCase(),
        live: false,
        featured: false,
        bonus: false,
        createdAt: now,
        opensAt: new Date(input.opensAt).getTime(),
        closesAt: new Date(input.closesAt).getTime(),
        resolvesAt: new Date(input.resolvesAt).getTime(),
        volumePaise: 0,
        liquidityPaise: input.initialLiquidityRupees * 100,
        traders: 0,
      })
      await tx.insert(marketOutcomes).values([
        { id: `${id}:yes`, marketId: id, name: input.yesLabel, side: 'yes', pricePaise: yesPricePaise, previousPricePaise: yesPricePaise },
        { id: `${id}:no`, marketId: id, name: input.noLabel, side: 'no', pricePaise: 1000 - yesPricePaise, previousPricePaise: 1000 - yesPricePaise },
      ])
      await tx.insert(marketPriceHistory).values({ id: randomUUID(), marketId: id, t: now, yesPricePaise })
    })

    return NextResponse.json({ ok: true, marketId: id })
  } catch (error) {
    if (error instanceof ZodError) return NextResponse.json({ ok: false, error: error.issues[0]?.message ?? 'Invalid market' }, { status: 400 })
    console.error('[v0] market creation failed', error)
    return NextResponse.json({ ok: false, error: 'The market could not be created. Try again.' }, { status: 500 })
  }
}
