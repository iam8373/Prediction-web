import { and, eq } from 'drizzle-orm'
import { NextResponse } from 'next/server'
import { z } from 'zod'

import { getCurrentUser } from '@/lib/auth/session'
import { db } from '@/lib/db'
import { markets } from '@/lib/db/schema'
import { lockResource } from '@/lib/trading/transaction-guards'

const schema = z.object({ marketId: z.string().min(1), status: z.enum(['open', 'paused', 'closed']) })

export async function POST(request: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ ok: false, error: 'Sign in with an admin account' }, { status: 401 })
  if (!user.isAdmin) return NextResponse.json({ ok: false, error: 'Admin access required' }, { status: 403 })

  try {
    const { marketId, status } = schema.parse(await request.json())
    const result = await db.transaction(async (tx) => {
      await lockResource(tx, 'market', marketId)
      const [market] = await tx.select({ id: markets.id, status: markets.status }).from(markets).where(eq(markets.id, marketId)).for('update').limit(1)
      if (!market) throw new Error('UNKNOWN_MARKET')
      if (market.status === 'resolved') throw new Error('MARKET_RESOLVED')
      const [updated] = await tx
        .update(markets)
        .set({ status })
        .where(and(eq(markets.id, marketId), eq(markets.status, market.status)))
        .returning({ id: markets.id })
      if (!updated) throw new Error('MARKET_CONFLICT')
      return { ok: true }
    })
    return NextResponse.json(result)
  } catch (error) {
    const message = error instanceof Error ? error.message : ''
    if (error instanceof z.ZodError) return NextResponse.json({ ok: false, error: error.issues[0]?.message ?? 'Invalid market status' }, { status: 400 })
    if (message === 'UNKNOWN_MARKET') return NextResponse.json({ ok: false, error: 'Unknown market' }, { status: 404 })
    if (message === 'MARKET_RESOLVED' || message === 'MARKET_CONFLICT') return NextResponse.json({ ok: false, error: 'Market has already changed. Refresh and try again.' }, { status: 409 })
    console.error('[v0] market status update failed', error)
    return NextResponse.json({ ok: false, error: 'The market status could not be updated' }, { status: 500 })
  }
}
