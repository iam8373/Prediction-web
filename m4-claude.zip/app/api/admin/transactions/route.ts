import { NextResponse } from 'next/server'

import { getCurrentUser } from '@/lib/auth/session'
import { getRefundableTransactions } from '@/lib/data/server-api'

export async function GET(request: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ ok: false, error: 'Sign in with an admin account' }, { status: 401 })
  if (!user.isAdmin) return NextResponse.json({ ok: false, error: 'Admin access required' }, { status: 403 })

  const query = new URL(request.url).searchParams.get('query') ?? ''
  const transactions = await getRefundableTransactions(query)
  return NextResponse.json({ ok: true, transactions })
}
