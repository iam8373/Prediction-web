import { and, eq, sql } from 'drizzle-orm'
import { NextResponse } from 'next/server'
import { randomUUID } from 'node:crypto'
import { ZodError } from 'zod'

import { getCurrentUser } from '@/lib/auth/session'
import { db } from '@/lib/db'
import { ledgerEntries, notifications, transactions, wallets } from '@/lib/db/schema'
import { getPaymentProvider } from '@/lib/payments/provider'
import { isUniqueViolation, lockResource } from '@/lib/trading/transaction-guards'
import { adminRefundSchema } from '@/lib/validation/schemas'

/**
 * Admin-only reversal for demo-money transactions. Two cases are refundable:
 *  - a completed deposit: debits the available balance back out
 *  - a pending withdrawal: unlocks the held funds and cancels the payout
 * Every other transaction type (trades, settlements, fees, existing refunds)
 * settles through its own flow and is rejected here.
 */
export async function POST(request: Request) {
  const admin = await getCurrentUser()
  if (!admin) return NextResponse.json({ ok: false, error: 'Sign in with an admin account' }, { status: 401 })
  if (!admin.isAdmin) return NextResponse.json({ ok: false, error: 'Admin access required' }, { status: 403 })

  try {
    const { transactionId, reason } = adminRefundSchema.parse(await request.json())
    const result = await db.transaction(async (tx) => {
      await lockResource(tx, 'refund', transactionId)
      const [original] = await tx
        .select()
        .from(transactions)
        .where(eq(transactions.id, transactionId))
        .for('update')
        .limit(1)
      if (!original) throw new Error('UNKNOWN_TRANSACTION')

      const isDeposit = original.type === 'deposit' && original.status === 'completed'
      const isWithdrawal = original.type === 'withdrawal' && original.status === 'pending'
      if (!isDeposit && !isWithdrawal) throw new Error('NOT_REFUNDABLE')

      const amount = Math.abs(original.amountPaise)
      const refundReference = `${original.reference}-REFUND`

      const [walletBefore] = await tx
        .select()
        .from(wallets)
        .where(eq(wallets.userId, original.userId))
        .for('update')
        .limit(1)
      if (!walletBefore) throw new Error('ACCOUNT_NOT_READY')
      if (isWithdrawal && walletBefore.lockedPaise < amount) throw new Error('LOCK_MISMATCH')
      if (isDeposit && walletBefore.availablePaise < amount) throw new Error('INSUFFICIENT_BALANCE')

      // Provider call is webhook-shaped: a real PSP integration would issue an
      // async refund here and settle on callback. The demo provider confirms
      // synchronously, but the idempotency key still guards against retries.
      const provider = getPaymentProvider()
      const refundIntent = await provider.refundPayment({
        amountPaise: amount,
        idempotencyKey: `refund:${transactionId}`,
        originalReference: original.reference,
      })
      if (refundIntent.status !== 'succeeded') throw new Error('REFUND_FAILED')

      const now = Date.now()
      const refundTransactionId = randomUUID()
      const label = isWithdrawal ? 'Withdrawal cancelled' : 'Deposit reversed'
      const description = reason ? `${label} by admin — ${reason}` : `${label} by admin`
      const refundAmountPaise = isWithdrawal ? amount : -amount

      const [wallet] = await tx
        .update(wallets)
        .set(
          isWithdrawal
            ? {
              lockedPaise: sql`${wallets.lockedPaise} - ${amount}`,
              availablePaise: sql`${wallets.availablePaise} + ${amount}`,
              updatedAt: new Date(),
            }
            : {
              availablePaise: sql`${wallets.availablePaise} - ${amount}`,
              updatedAt: new Date(),
            },
        )
        .where(and(
          eq(wallets.userId, original.userId),
          isWithdrawal ? sql`${wallets.lockedPaise} >= ${amount}` : sql`${wallets.availablePaise} >= ${amount}`,
        ))
        .returning({ availablePaise: wallets.availablePaise, lockedPaise: wallets.lockedPaise, bonusPaise: wallets.bonusPaise })
      if (!wallet) throw new Error(isWithdrawal ? 'LOCK_MISMATCH' : 'INSUFFICIENT_BALANCE')

      if (isWithdrawal) {
        await tx
          .update(transactions)
          .set({ status: 'failed' })
          .where(and(eq(transactions.id, original.id), eq(transactions.status, 'pending')))
        await tx
          .update(ledgerEntries)
          .set({ status: 'failed' })
          .where(and(eq(ledgerEntries.reference, original.reference), eq(ledgerEntries.status, 'pending')))
      }

      // Unique on `reference` — a concurrent second refund attempt for the
      // same transaction collides here and surfaces as ALREADY_REFUNDED below.
      await tx.insert(transactions).values({
        id: refundTransactionId,
        userId: original.userId,
        reference: refundReference,
        type: 'refund',
        amountPaise: refundAmountPaise,
        status: 'completed',
        description,
        marketId: original.marketId,
        createdAt: now,
      })
      await tx.insert(ledgerEntries).values({
        id: `ledger_${refundTransactionId}`,
        userId: original.userId,
        reference: refundReference,
        type: 'refund',
        amountPaise: refundAmountPaise,
        status: 'completed',
        description,
        marketId: original.marketId,
        createdAt: now,
      })
      await tx.insert(notifications).values({
        id: `notification_${refundTransactionId}`,
        userId: original.userId,
        eventKey: `refund:${refundTransactionId}`,
        kind: 'account',
        title: isWithdrawal ? 'Withdrawal cancelled' : 'Deposit refunded',
        description,
        href: '/wallet',
        createdAt: now,
      }).onConflictDoNothing()

      return { ok: true, transactionId: refundTransactionId, userId: original.userId, wallet }
    })
    return NextResponse.json(result)
  } catch (error) {
    if (isUniqueViolation(error)) {
      return NextResponse.json({ ok: false, error: 'This transaction has already been refunded' }, { status: 409 })
    }
    const message = error instanceof Error ? error.message : ''
    if (error instanceof ZodError) return NextResponse.json({ ok: false, error: error.issues[0]?.message ?? 'Invalid refund request' }, { status: 400 })
    const errors: Record<string, { error: string; status: number }> = {
      UNKNOWN_TRANSACTION: { error: 'Transaction not found', status: 404 },
      NOT_REFUNDABLE: { error: 'This transaction cannot be refunded', status: 409 },
      ACCOUNT_NOT_READY: { error: 'That trader wallet is not ready yet', status: 409 },
      LOCK_MISMATCH: { error: 'The locked balance no longer matches this withdrawal. Refresh and try again.', status: 409 },
      INSUFFICIENT_BALANCE: { error: 'The trader no longer has enough available balance to reverse this deposit', status: 409 },
      REFUND_FAILED: { error: 'The refund could not be confirmed', status: 502 },
    }
    if (errors[message]) return NextResponse.json({ ok: false, error: errors[message].error }, { status: errors[message].status })
    console.error('[v0] admin refund failed', error)
    return NextResponse.json({ ok: false, error: 'The refund could not be processed' }, { status: 500 })
  }
}
