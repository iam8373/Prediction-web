import { NextResponse } from 'next/server'
import { ZodError } from 'zod'

import { createSession, getSessionCookieOptions, requestOtp, verifyOtp } from '@/lib/auth/session'

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { action?: string; phone?: string; otp?: string }

    if (body.action === 'request') {
      const result = await requestOtp(body.phone ?? '')
      return NextResponse.json({ ok: true, demoCode: result.demoCode })
    }

    if (body.action === 'verify') {
      const user = await verifyOtp(body.phone ?? '', body.otp ?? '')
      const token = await createSession(user.id)
      const response = NextResponse.json({ ok: true, user })
      response.cookies.set('predik_session', token, getSessionCookieOptions())
      return response
    }

    return NextResponse.json({ ok: false, error: 'Unsupported authentication action' }, { status: 400 })
  } catch (error) {
    if (error instanceof ZodError || error instanceof Error && error.message === 'INVALID_OTP') {
      return NextResponse.json({ ok: false, error: error instanceof Error && error.message === 'INVALID_OTP' ? 'That code did not match or has expired. Request a new one.' : 'Enter a valid phone number and code.' }, { status: 400 })
    }
    console.error('[v0] OTP request failed', error)
    return NextResponse.json({ ok: false, error: 'We could not complete sign in. Try again.' }, { status: 500 })
  }
}
