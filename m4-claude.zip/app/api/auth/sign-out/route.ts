import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

import { clearSession, getSessionCookieOptions, SESSION_COOKIE } from '@/lib/auth/session'

export async function POST() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  await clearSession(token)

  const response = NextResponse.json({ ok: true })
  response.cookies.set(SESSION_COOKIE, '', { ...getSessionCookieOptions(), maxAge: 0 })
  return response
}
