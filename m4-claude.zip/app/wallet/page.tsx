'use client'

import { ArrowDownToLine, ArrowUpFromLine } from 'lucide-react'
import { useState } from 'react'

import { AppShell } from '@/components/layout/app-shell'
import { AuthGate } from '@/components/trading/auth-gate'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/primitives'
import { DepositModal } from '@/components/wallet/deposit-modal'
import { TransactionList } from '@/components/wallet/transaction-list'
import { WithdrawModal } from '@/components/wallet/withdraw-modal'
import { formatINR } from '@/lib/money'
import { useAppStore } from '@/lib/store/use-app-store'

export default function WalletPage() {
  const user = useAppStore((s) => s.user)
  const wallet = useAppStore((s) => s.wallet)
  const transactions = useAppStore((s) => s.transactions)
  const [depositOpen, setDepositOpen] = useState(false)
  const [withdrawOpen, setWithdrawOpen] = useState(false)

  if (!user) {
    return (
      <AppShell>
        <AuthGate message="Sign in to manage your wallet, deposits and withdrawals." />
      </AppShell>
    )
  }

  return (
    <AppShell>
      <div className="space-y-5">
        <h1 className="text-lg font-bold text-foreground">Wallet</h1>

        <Card className="p-5">
          <p className="text-xs text-muted-foreground">Available balance</p>
          <p className="mt-1 text-3xl font-bold tabular-nums text-foreground">{formatINR(wallet.availablePaise)}</p>
          <div className="mt-4 flex gap-2">
            <Button className="h-10 flex-1 rounded-xl" onClick={() => setDepositOpen(true)}>
              <ArrowDownToLine className="size-4" /> Add funds
            </Button>
            <Button variant="outline" className="h-10 flex-1 rounded-xl" onClick={() => setWithdrawOpen(true)}>
              <ArrowUpFromLine className="size-4" /> Withdraw
            </Button>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 border-t border-border pt-4 text-sm">
            <div>
              <p className="text-muted-foreground">Locked in withdrawals</p>
              <p className="font-semibold">{formatINR(wallet.lockedPaise)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Bonus balance</p>
              <p className="font-semibold">{formatINR(wallet.bonusPaise)}</p>
            </div>
          </div>
        </Card>

        <section>
          <h2 className="mb-2 text-sm font-semibold text-foreground">Transactions</h2>
          <TransactionList transactions={transactions} />
        </section>
      </div>

      <DepositModal open={depositOpen} onClose={() => setDepositOpen(false)} />
      <WithdrawModal open={withdrawOpen} onClose={() => setWithdrawOpen(false)} />
    </AppShell>
  )
}
